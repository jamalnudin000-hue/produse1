require('dotenv').config()
const express = require('express')
const mysql = require('mysql2/promise')
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')
const cookieParser = require('cookie-parser')
const cors = require('cors')

const app = express()

app.use(cors({ origin: true, credentials: true }))
app.use(express.json())
app.use(cookieParser())

// Pool MySQL
const pool = mysql.createPool({
  host: process.env.DB_HOST || '127.0.0.1',
  port: process.env.DB_PORT ? Number(process.env.DB_PORT) : 3306,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
})

// Helper: auth middleware
function requireAuth(req, res, next) {
  const token = req.cookies?.token || (req.headers.authorization?.split(' ')[1])
  if (!token) return res.status(401).json({ message: 'Unauthorized' })
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET)
    req.userId = payload.sub
    next()
  } catch (e) {
    return res.status(401).json({ message: 'Invalid token' })
  }
}

// Register
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, username, password } = req.body
    if (!name || !email || !password) {
      return res.status(400).json({ message: 'name, email, password wajib' })
    }
    if (password.length < 8) {
      return res.status(400).json({ message: 'Password minimal 8 karakter' })
    }
    const conn = await pool.getConnection()
    try {
      const [exists] = await conn.execute(
        'SELECT id FROM users WHERE email = ? OR (username IS NOT NULL AND username = ?)',
        [email, username || null]
      )
      if (exists.length) {
        return res.status(409).json({ message: 'Email/username sudah dipakai' })
      }
      const hash = await bcrypt.hash(password, 12)
      const [result] = await conn.execute(
        'INSERT INTO users (name, email, username, password_hash) VALUES (?,?,?,?)',
        [name, email, username || null, hash]
      )
      const userId = result.insertId
      const token = jwt.sign({ sub: userId }, process.env.JWT_SECRET, { expiresIn: '7d' })
      res.cookie('token', token, { httpOnly: true, sameSite: 'lax' /*, secure: true saat HTTPS*/ })
      return res.status(201).json({ id: userId, name, email, username })
    } finally {
      conn.release()
    }
  } catch (e) {
    console.error(e)
    return res.status(500).json({ message: 'Server error' })
  }
})

// Login
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body
    if (!email || !password) return res.status(400).json({ message: 'email & password wajib' })
    const conn = await pool.getConnection()
    try {
      const [rows] = await conn.execute(
        'SELECT id, name, email, username, password_hash FROM users WHERE email = ? LIMIT 1',
        [email]
      )
      if (!rows.length) return res.status(401).json({ message: 'Email atau password salah' })
      const user = rows[0]
      const ok = await bcrypt.compare(password, user.password_hash)
      if (!ok) return res.status(401).json({ message: 'Email atau password salah' })

      const token = jwt.sign({ sub: user.id }, process.env.JWT_SECRET, { expiresIn: '7d' })
      res.cookie('token', token, { httpOnly: true, sameSite: 'lax' })
      return res.json({ id: user.id, name: user.name, email: user.email, username: user.username })
    } finally {
      conn.release()
    }
  } catch (e) {
    console.error(e)
    return res.status(500).json({ message: 'Server error' })
  }
})

// Profil (cek login)
app.get('/api/auth/me', requireAuth, async (req, res) => {
  try {
    const conn = await pool.getConnection()
    try {
      const [rows] = await conn.execute(
        'SELECT id, name, email, username, created_at FROM users WHERE id = ? LIMIT 1',
        [req.userId]
      )
      if (!rows.length) return res.status(404).json({ message: 'User tidak ditemukan' })
      return res.json(rows[0])
    } finally {
      conn.release()
    }
  } catch (e) {
    console.error(e)
    return res.status(500).json({ message: 'Server error' })
  }
})

// Logout (hapus cookie)
app.post('/api/auth/logout', (req, res) => {
  res.clearCookie('token')
  res.json({ message: 'Logged out' })
})

app.listen(process.env.PORT || 3000, () => {
  console.log('API ready at http://127.0.0.1:' + (process.env.PORT || 3000))
})


app.get('/health/db', async (req, res) => {
  try {
    const conn = await pool.getConnection();
    const [rows] = await conn.query('SELECT 1 AS ok');
    conn.release();
    res.json({ db: 'ok', rows });
  } catch (e) {
    console.error('DB health error:', e.message);
    res.status(500).json({ db: 'error', message: e.message });
  }
});
